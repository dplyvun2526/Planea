namespace ProyectoDeskstop
{
    partial class Form2
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.Label lblSaludo;
        private System.Windows.Forms.Label lblSubtitulo;
        private System.Windows.Forms.Panel panelHoras;
        private System.Windows.Forms.Label lblHorasTitulo;
        private System.Windows.Forms.Label lblHorasValor;
        private System.Windows.Forms.Panel panelStat1;
        private System.Windows.Forms.Label lblStat1Titulo;
        private System.Windows.Forms.Label lblStat1Valor;
        private System.Windows.Forms.Panel panelStat2;
        private System.Windows.Forms.Label lblStat2Titulo;
        private System.Windows.Forms.Label lblStat2Valor;
        private System.Windows.Forms.Panel panelStat3;
        private System.Windows.Forms.Label lblStat3Titulo;
        private System.Windows.Forms.Label lblStat3Valor;
        private System.Windows.Forms.Panel panelStat4;
        private System.Windows.Forms.Label lblStat4Titulo;
        private System.Windows.Forms.Label lblStat4Valor;
        private System.Windows.Forms.Panel panelRecientes;
        private System.Windows.Forms.Label lblRecientesTitulo;
        private System.Windows.Forms.Label lblRecientesSub;
        private System.Windows.Forms.Label lblProy1Nombre;
        private System.Windows.Forms.Label lblProy1Detalle;
        private System.Windows.Forms.ProgressBar pbProy1;
        private System.Windows.Forms.Label lblProy1Porcentaje;
        private System.Windows.Forms.Label lblProy1Estado;
        private System.Windows.Forms.Label lblProy1Entrega;
        private System.Windows.Forms.Label lblProy2Nombre;
        private System.Windows.Forms.Label lblProy2Detalle;
        private System.Windows.Forms.ProgressBar pbProy2;
        private System.Windows.Forms.Label lblProy2Porcentaje;
        private System.Windows.Forms.Label lblProy2Estado;
        private System.Windows.Forms.Label lblProy2Entrega;
        private System.Windows.Forms.Label lblProy3Nombre;
        private System.Windows.Forms.Label lblProy3Detalle;
        private System.Windows.Forms.ProgressBar pbProy3;
        private System.Windows.Forms.Label lblProy3Porcentaje;
        private System.Windows.Forms.Label lblProy3Estado;
        private System.Windows.Forms.Label lblProy3Entrega;
        private System.Windows.Forms.Panel panelEstado;
        private System.Windows.Forms.Label lblEstadoTitulo;
        private System.Windows.Forms.Label lblEstadoSub;
        private System.Windows.Forms.Panel panelDonaEstado;
        private System.Windows.Forms.Panel panelPunto1;
        private System.Windows.Forms.Panel panelPunto2;
        private System.Windows.Forms.Panel panelPunto3;
        private System.Windows.Forms.Label lblLeyenda1;
        private System.Windows.Forms.Label lblLeyenda2;
        private System.Windows.Forms.Label lblLeyenda3;
        private System.Windows.Forms.Label lblLeyendaValor1;
        private System.Windows.Forms.Label lblLeyendaValor2;
        private System.Windows.Forms.Label lblLeyendaValor3;
        private System.Windows.Forms.Panel panelProximas;
        private System.Windows.Forms.Label lblProxTitulo;
        private System.Windows.Forms.Label lblProxSub;
        private System.Windows.Forms.Panel panelProx1;
        private System.Windows.Forms.Label lblProx1Titulo;
        private System.Windows.Forms.Label lblProx1Proyecto;
        private System.Windows.Forms.Label lblProx1Fecha;
        private System.Windows.Forms.Label lblProx1Iniciales;
        private System.Windows.Forms.Panel panelProx2;
        private System.Windows.Forms.Label lblProx2Titulo;
        private System.Windows.Forms.Label lblProx2Proyecto;
        private System.Windows.Forms.Label lblProx2Fecha;
        private System.Windows.Forms.Label lblProx2Iniciales;
        private System.Windows.Forms.Panel panelProx3;
        private System.Windows.Forms.Label lblProx3Titulo;
        private System.Windows.Forms.Label lblProx3Proyecto;
        private System.Windows.Forms.Label lblProx3Fecha;
        private System.Windows.Forms.Label lblProx3Iniciales;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.lblFecha = new System.Windows.Forms.Label();
            this.lblSaludo = new System.Windows.Forms.Label();
            this.lblSubtitulo = new System.Windows.Forms.Label();
            this.panelHoras = new System.Windows.Forms.Panel();
            this.lblHorasTitulo = new System.Windows.Forms.Label();
            this.lblHorasValor = new System.Windows.Forms.Label();
            this.panelStat1 = new System.Windows.Forms.Panel();
            this.lblStat1Titulo = new System.Windows.Forms.Label();
            this.lblStat1Valor = new System.Windows.Forms.Label();
            this.panelStat2 = new System.Windows.Forms.Panel();
            this.lblStat2Titulo = new System.Windows.Forms.Label();
            this.lblStat2Valor = new System.Windows.Forms.Label();
            this.panelStat3 = new System.Windows.Forms.Panel();
            this.lblStat3Titulo = new System.Windows.Forms.Label();
            this.lblStat3Valor = new System.Windows.Forms.Label();
            this.panelStat4 = new System.Windows.Forms.Panel();
            this.lblStat4Titulo = new System.Windows.Forms.Label();
            this.lblStat4Valor = new System.Windows.Forms.Label();
            this.panelRecientes = new System.Windows.Forms.Panel();
            this.lblRecientesTitulo = new System.Windows.Forms.Label();
            this.lblRecientesSub = new System.Windows.Forms.Label();
            this.lblProy1Nombre = new System.Windows.Forms.Label();
            this.lblProy1Detalle = new System.Windows.Forms.Label();
            this.pbProy1 = new System.Windows.Forms.ProgressBar();
            this.lblProy1Porcentaje = new System.Windows.Forms.Label();
            this.lblProy1Estado = new System.Windows.Forms.Label();
            this.lblProy1Entrega = new System.Windows.Forms.Label();
            this.lblProy2Nombre = new System.Windows.Forms.Label();
            this.lblProy2Detalle = new System.Windows.Forms.Label();
            this.pbProy2 = new System.Windows.Forms.ProgressBar();
            this.lblProy2Porcentaje = new System.Windows.Forms.Label();
            this.lblProy2Estado = new System.Windows.Forms.Label();
            this.lblProy2Entrega = new System.Windows.Forms.Label();
            this.lblProy3Nombre = new System.Windows.Forms.Label();
            this.lblProy3Detalle = new System.Windows.Forms.Label();
            this.pbProy3 = new System.Windows.Forms.ProgressBar();
            this.lblProy3Porcentaje = new System.Windows.Forms.Label();
            this.lblProy3Estado = new System.Windows.Forms.Label();
            this.lblProy3Entrega = new System.Windows.Forms.Label();
            this.panelEstado = new System.Windows.Forms.Panel();
            this.lblEstadoTitulo = new System.Windows.Forms.Label();
            this.lblEstadoSub = new System.Windows.Forms.Label();
            this.panelDonaEstado = new System.Windows.Forms.Panel();
            this.panelPunto1 = new System.Windows.Forms.Panel();
            this.panelPunto2 = new System.Windows.Forms.Panel();
            this.panelPunto3 = new System.Windows.Forms.Panel();
            this.lblLeyenda1 = new System.Windows.Forms.Label();
            this.lblLeyenda2 = new System.Windows.Forms.Label();
            this.lblLeyenda3 = new System.Windows.Forms.Label();
            this.lblLeyendaValor1 = new System.Windows.Forms.Label();
            this.lblLeyendaValor2 = new System.Windows.Forms.Label();
            this.lblLeyendaValor3 = new System.Windows.Forms.Label();
            this.panelProximas = new System.Windows.Forms.Panel();
            this.lblProxTitulo = new System.Windows.Forms.Label();
            this.lblProxSub = new System.Windows.Forms.Label();
            this.panelProx1 = new System.Windows.Forms.Panel();
            this.lblProx1Titulo = new System.Windows.Forms.Label();
            this.lblProx1Proyecto = new System.Windows.Forms.Label();
            this.lblProx1Fecha = new System.Windows.Forms.Label();
            this.lblProx1Iniciales = new System.Windows.Forms.Label();
            this.panelProx2 = new System.Windows.Forms.Panel();
            this.lblProx2Titulo = new System.Windows.Forms.Label();
            this.lblProx2Proyecto = new System.Windows.Forms.Label();
            this.lblProx2Fecha = new System.Windows.Forms.Label();
            this.lblProx2Iniciales = new System.Windows.Forms.Label();
            this.panelProx3 = new System.Windows.Forms.Panel();
            this.lblProx3Titulo = new System.Windows.Forms.Label();
            this.lblProx3Proyecto = new System.Windows.Forms.Label();
            this.lblProx3Fecha = new System.Windows.Forms.Label();
            this.lblProx3Iniciales = new System.Windows.Forms.Label();
            this.panelHoras.SuspendLayout();
            this.panelStat1.SuspendLayout();
            this.panelStat2.SuspendLayout();
            this.panelStat3.SuspendLayout();
            this.panelStat4.SuspendLayout();
            this.panelRecientes.SuspendLayout();
            this.panelEstado.SuspendLayout();
            this.panelProximas.SuspendLayout();
            this.panelProx1.SuspendLayout();
            this.panelProx2.SuspendLayout();
            this.panelProx3.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblFecha.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblFecha.Location = new System.Drawing.Point(30, 20);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Text = "FECHA";
            // 
            // lblSaludo
            // 
            this.lblSaludo.AutoSize = true;
            this.lblSaludo.Font = new System.Drawing.Font("Segoe UI", 22F);
            this.lblSaludo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblSaludo.Location = new System.Drawing.Point(30, 40);
            this.lblSaludo.Name = "lblSaludo";
            this.lblSaludo.Text = "Buenos días";
            // 
            // lblSubtitulo
            // 
            this.lblSubtitulo.AutoSize = true;
            this.lblSubtitulo.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubtitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblSubtitulo.Location = new System.Drawing.Point(30, 85);
            this.lblSubtitulo.Name = "lblSubtitulo";
            this.lblSubtitulo.Text = "Aquí tienes una visión general del trabajo de tu equipo.";
            // 
            // panelHoras
            // 
            this.panelHoras.BackColor = System.Drawing.Color.White;
            this.panelHoras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelHoras.Controls.Add(this.lblHorasTitulo);
            this.panelHoras.Controls.Add(this.lblHorasValor);
            this.panelHoras.Location = new System.Drawing.Point(760, 30);
            this.panelHoras.Name = "panelHoras";
            this.panelHoras.Size = new System.Drawing.Size(200, 70);
            // 
            // lblHorasTitulo
            // 
            this.lblHorasTitulo.AutoSize = true;
            this.lblHorasTitulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasTitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasTitulo.Location = new System.Drawing.Point(14, 12);
            this.lblHorasTitulo.Name = "lblHorasTitulo";
            this.lblHorasTitulo.Text = "Horas este mes";
            // 
            // lblHorasValor
            // 
            this.lblHorasValor.AutoSize = true;
            this.lblHorasValor.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHorasValor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasValor.Location = new System.Drawing.Point(14, 32);
            this.lblHorasValor.Name = "lblHorasValor";
            this.lblHorasValor.Text = "126,5 h";
            // 
            // panelStat1
            // 
            this.panelStat1.BackColor = System.Drawing.Color.White;
            this.panelStat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat1.Controls.Add(this.lblStat1Titulo);
            this.panelStat1.Controls.Add(this.lblStat1Valor);
            this.panelStat1.Location = new System.Drawing.Point(30, 125);
            this.panelStat1.Name = "panelStat1";
            this.panelStat1.Size = new System.Drawing.Size(210, 80);
            // 
            // lblStat1Titulo
            // 
            this.lblStat1Titulo.AutoSize = true;
            this.lblStat1Titulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStat1Titulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStat1Titulo.Location = new System.Drawing.Point(14, 14);
            this.lblStat1Titulo.Name = "lblStat1Titulo";
            this.lblStat1Titulo.Text = "Proyectos activos";
            // 
            // lblStat1Valor
            // 
            this.lblStat1Valor.AutoSize = true;
            this.lblStat1Valor.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStat1Valor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStat1Valor.Location = new System.Drawing.Point(14, 34);
            this.lblStat1Valor.Name = "lblStat1Valor";
            this.lblStat1Valor.Text = "0";
            // 
            // panelStat2
            // 
            this.panelStat2.BackColor = System.Drawing.Color.White;
            this.panelStat2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat2.Controls.Add(this.lblStat2Titulo);
            this.panelStat2.Controls.Add(this.lblStat2Valor);
            this.panelStat2.Location = new System.Drawing.Point(255, 125);
            this.panelStat2.Name = "panelStat2";
            this.panelStat2.Size = new System.Drawing.Size(210, 80);
            // 
            // lblStat2Titulo
            // 
            this.lblStat2Titulo.AutoSize = true;
            this.lblStat2Titulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStat2Titulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStat2Titulo.Location = new System.Drawing.Point(14, 14);
            this.lblStat2Titulo.Name = "lblStat2Titulo";
            this.lblStat2Titulo.Text = "Tareas pendientes";
            // 
            // lblStat2Valor
            // 
            this.lblStat2Valor.AutoSize = true;
            this.lblStat2Valor.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStat2Valor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStat2Valor.Location = new System.Drawing.Point(14, 34);
            this.lblStat2Valor.Name = "lblStat2Valor";
            this.lblStat2Valor.Text = "0";
            // 
            // panelStat3
            // 
            this.panelStat3.BackColor = System.Drawing.Color.White;
            this.panelStat3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat3.Controls.Add(this.lblStat3Titulo);
            this.panelStat3.Controls.Add(this.lblStat3Valor);
            this.panelStat3.Location = new System.Drawing.Point(480, 125);
            this.panelStat3.Name = "panelStat3";
            this.panelStat3.Size = new System.Drawing.Size(210, 80);
            // 
            // lblStat3Titulo
            // 
            this.lblStat3Titulo.AutoSize = true;
            this.lblStat3Titulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStat3Titulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStat3Titulo.Location = new System.Drawing.Point(14, 14);
            this.lblStat3Titulo.Name = "lblStat3Titulo";
            this.lblStat3Titulo.Text = "En progreso";
            // 
            // lblStat3Valor
            // 
            this.lblStat3Valor.AutoSize = true;
            this.lblStat3Valor.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStat3Valor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStat3Valor.Location = new System.Drawing.Point(14, 34);
            this.lblStat3Valor.Name = "lblStat3Valor";
            this.lblStat3Valor.Text = "0";
            // 
            // panelStat4
            // 
            this.panelStat4.BackColor = System.Drawing.Color.White;
            this.panelStat4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat4.Controls.Add(this.lblStat4Titulo);
            this.panelStat4.Controls.Add(this.lblStat4Valor);
            this.panelStat4.Location = new System.Drawing.Point(705, 125);
            this.panelStat4.Name = "panelStat4";
            this.panelStat4.Size = new System.Drawing.Size(210, 80);
            // 
            // lblStat4Titulo
            // 
            this.lblStat4Titulo.AutoSize = true;
            this.lblStat4Titulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStat4Titulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStat4Titulo.Location = new System.Drawing.Point(14, 14);
            this.lblStat4Titulo.Name = "lblStat4Titulo";
            this.lblStat4Titulo.Text = "Finalizadas";
            // 
            // lblStat4Valor
            // 
            this.lblStat4Valor.AutoSize = true;
            this.lblStat4Valor.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStat4Valor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStat4Valor.Location = new System.Drawing.Point(14, 34);
            this.lblStat4Valor.Name = "lblStat4Valor";
            this.lblStat4Valor.Text = "0";
            // 
            // panelRecientes
            // 
            this.panelRecientes.BackColor = System.Drawing.Color.White;
            this.panelRecientes.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelRecientes.Controls.Add(this.lblRecientesTitulo);
            this.panelRecientes.Controls.Add(this.lblRecientesSub);
            this.panelRecientes.Controls.Add(this.lblProy1Nombre);
            this.panelRecientes.Controls.Add(this.lblProy1Detalle);
            this.panelRecientes.Controls.Add(this.pbProy1);
            this.panelRecientes.Controls.Add(this.lblProy1Porcentaje);
            this.panelRecientes.Controls.Add(this.lblProy1Estado);
            this.panelRecientes.Controls.Add(this.lblProy1Entrega);
            this.panelRecientes.Controls.Add(this.lblProy2Nombre);
            this.panelRecientes.Controls.Add(this.lblProy2Detalle);
            this.panelRecientes.Controls.Add(this.pbProy2);
            this.panelRecientes.Controls.Add(this.lblProy2Porcentaje);
            this.panelRecientes.Controls.Add(this.lblProy2Estado);
            this.panelRecientes.Controls.Add(this.lblProy2Entrega);
            this.panelRecientes.Controls.Add(this.lblProy3Nombre);
            this.panelRecientes.Controls.Add(this.lblProy3Detalle);
            this.panelRecientes.Controls.Add(this.pbProy3);
            this.panelRecientes.Controls.Add(this.lblProy3Porcentaje);
            this.panelRecientes.Controls.Add(this.lblProy3Estado);
            this.panelRecientes.Controls.Add(this.lblProy3Entrega);
            this.panelRecientes.Location = new System.Drawing.Point(30, 225);
            this.panelRecientes.Name = "panelRecientes";
            this.panelRecientes.Size = new System.Drawing.Size(560, 330);
            // 
            // lblRecientesTitulo
            // 
            this.lblRecientesTitulo.AutoSize = true;
            this.lblRecientesTitulo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblRecientesTitulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblRecientesTitulo.Location = new System.Drawing.Point(15, 14);
            this.lblRecientesTitulo.Name = "lblRecientesTitulo";
            this.lblRecientesTitulo.Text = "Proyectos recientes";
            // 
            // lblRecientesSub
            // 
            this.lblRecientesSub.AutoSize = true;
            this.lblRecientesSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblRecientesSub.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblRecientesSub.Location = new System.Drawing.Point(15, 38);
            this.lblRecientesSub.Name = "lblRecientesSub";
            this.lblRecientesSub.Text = "Progreso de los proyectos en los que participas";
            // 
            // lblProy1Nombre
            // 
            this.lblProy1Nombre.AutoSize = true;
            this.lblProy1Nombre.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProy1Nombre.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy1Nombre.Location = new System.Drawing.Point(15, 75);
            this.lblProy1Nombre.Name = "lblProy1Nombre";
            this.lblProy1Nombre.Text = "Proyecto 1";
            // 
            // lblProy1Detalle
            // 
            this.lblProy1Detalle.AutoSize = true;
            this.lblProy1Detalle.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy1Detalle.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy1Detalle.Location = new System.Drawing.Point(15, 97);
            this.lblProy1Detalle.Name = "lblProy1Detalle";
            this.lblProy1Detalle.Text = "0 de 0 tareas completadas";
            // 
            // pbProy1
            // 
            this.pbProy1.Location = new System.Drawing.Point(15, 121);
            this.pbProy1.Name = "pbProy1";
            this.pbProy1.Size = new System.Drawing.Size(400, 10);
            // 
            // lblProy1Porcentaje
            // 
            this.lblProy1Porcentaje.AutoSize = true;
            this.lblProy1Porcentaje.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy1Porcentaje.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy1Porcentaje.Location = new System.Drawing.Point(425, 117);
            this.lblProy1Porcentaje.Name = "lblProy1Porcentaje";
            this.lblProy1Porcentaje.Text = "0%";
            // 
            // lblProy1Estado
            // 
            this.lblProy1Estado.AutoSize = true;
            this.lblProy1Estado.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy1Estado.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy1Estado.Location = new System.Drawing.Point(440, 75);
            this.lblProy1Estado.Name = "lblProy1Estado";
            this.lblProy1Estado.Padding = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.lblProy1Estado.Text = "Estado";
            // 
            // lblProy1Entrega
            // 
            this.lblProy1Entrega.AutoSize = true;
            this.lblProy1Entrega.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy1Entrega.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy1Entrega.Location = new System.Drawing.Point(440, 101);
            this.lblProy1Entrega.Name = "lblProy1Entrega";
            this.lblProy1Entrega.Text = "";
            // 
            // lblProy2Nombre
            // 
            this.lblProy2Nombre.AutoSize = true;
            this.lblProy2Nombre.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProy2Nombre.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy2Nombre.Location = new System.Drawing.Point(15, 155);
            this.lblProy2Nombre.Name = "lblProy2Nombre";
            this.lblProy2Nombre.Text = "Proyecto 2";
            // 
            // lblProy2Detalle
            // 
            this.lblProy2Detalle.AutoSize = true;
            this.lblProy2Detalle.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy2Detalle.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy2Detalle.Location = new System.Drawing.Point(15, 177);
            this.lblProy2Detalle.Name = "lblProy2Detalle";
            this.lblProy2Detalle.Text = "0 de 0 tareas completadas";
            // 
            // pbProy2
            // 
            this.pbProy2.Location = new System.Drawing.Point(15, 201);
            this.pbProy2.Name = "pbProy2";
            this.pbProy2.Size = new System.Drawing.Size(400, 10);
            // 
            // lblProy2Porcentaje
            // 
            this.lblProy2Porcentaje.AutoSize = true;
            this.lblProy2Porcentaje.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy2Porcentaje.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy2Porcentaje.Location = new System.Drawing.Point(425, 197);
            this.lblProy2Porcentaje.Name = "lblProy2Porcentaje";
            this.lblProy2Porcentaje.Text = "0%";
            // 
            // lblProy2Estado
            // 
            this.lblProy2Estado.AutoSize = true;
            this.lblProy2Estado.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy2Estado.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy2Estado.Location = new System.Drawing.Point(440, 155);
            this.lblProy2Estado.Name = "lblProy2Estado";
            this.lblProy2Estado.Padding = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.lblProy2Estado.Text = "Estado";
            // 
            // lblProy2Entrega
            // 
            this.lblProy2Entrega.AutoSize = true;
            this.lblProy2Entrega.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy2Entrega.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy2Entrega.Location = new System.Drawing.Point(440, 181);
            this.lblProy2Entrega.Name = "lblProy2Entrega";
            this.lblProy2Entrega.Text = "";
            // 
            // lblProy3Nombre
            // 
            this.lblProy3Nombre.AutoSize = true;
            this.lblProy3Nombre.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProy3Nombre.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy3Nombre.Location = new System.Drawing.Point(15, 235);
            this.lblProy3Nombre.Name = "lblProy3Nombre";
            this.lblProy3Nombre.Text = "Proyecto 3";
            // 
            // lblProy3Detalle
            // 
            this.lblProy3Detalle.AutoSize = true;
            this.lblProy3Detalle.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy3Detalle.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy3Detalle.Location = new System.Drawing.Point(15, 257);
            this.lblProy3Detalle.Name = "lblProy3Detalle";
            this.lblProy3Detalle.Text = "0 de 0 tareas completadas";
            // 
            // pbProy3
            // 
            this.pbProy3.Location = new System.Drawing.Point(15, 281);
            this.pbProy3.Name = "pbProy3";
            this.pbProy3.Size = new System.Drawing.Size(400, 10);
            // 
            // lblProy3Porcentaje
            // 
            this.lblProy3Porcentaje.AutoSize = true;
            this.lblProy3Porcentaje.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy3Porcentaje.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy3Porcentaje.Location = new System.Drawing.Point(425, 277);
            this.lblProy3Porcentaje.Name = "lblProy3Porcentaje";
            this.lblProy3Porcentaje.Text = "0%";
            // 
            // lblProy3Estado
            // 
            this.lblProy3Estado.AutoSize = true;
            this.lblProy3Estado.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy3Estado.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProy3Estado.Location = new System.Drawing.Point(440, 235);
            this.lblProy3Estado.Name = "lblProy3Estado";
            this.lblProy3Estado.Padding = new System.Windows.Forms.Padding(6, 2, 6, 2);
            this.lblProy3Estado.Text = "Estado";
            // 
            // lblProy3Entrega
            // 
            this.lblProy3Entrega.AutoSize = true;
            this.lblProy3Entrega.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProy3Entrega.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProy3Entrega.Location = new System.Drawing.Point(440, 261);
            this.lblProy3Entrega.Name = "lblProy3Entrega";
            this.lblProy3Entrega.Text = "";
            // 
            // panelEstado
            // 
            this.panelEstado.BackColor = System.Drawing.Color.White;
            this.panelEstado.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEstado.Controls.Add(this.lblEstadoTitulo);
            this.panelEstado.Controls.Add(this.lblEstadoSub);
            this.panelEstado.Controls.Add(this.panelDonaEstado);
            this.panelEstado.Controls.Add(this.panelPunto1);
            this.panelEstado.Controls.Add(this.panelPunto2);
            this.panelEstado.Controls.Add(this.panelPunto3);
            this.panelEstado.Controls.Add(this.lblLeyenda1);
            this.panelEstado.Controls.Add(this.lblLeyenda2);
            this.panelEstado.Controls.Add(this.lblLeyenda3);
            this.panelEstado.Controls.Add(this.lblLeyendaValor1);
            this.panelEstado.Controls.Add(this.lblLeyendaValor2);
            this.panelEstado.Controls.Add(this.lblLeyendaValor3);
            this.panelEstado.Location = new System.Drawing.Point(610, 225);
            this.panelEstado.Name = "panelEstado";
            this.panelEstado.Size = new System.Drawing.Size(350, 330);
            // 
            // lblEstadoTitulo
            // 
            this.lblEstadoTitulo.AutoSize = true;
            this.lblEstadoTitulo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblEstadoTitulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoTitulo.Location = new System.Drawing.Point(15, 14);
            this.lblEstadoTitulo.Name = "lblEstadoTitulo";
            this.lblEstadoTitulo.Text = "Estado de tareas";
            // 
            // lblEstadoSub
            // 
            this.lblEstadoSub.AutoSize = true;
            this.lblEstadoSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblEstadoSub.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEstadoSub.Location = new System.Drawing.Point(15, 38);
            this.lblEstadoSub.Name = "lblEstadoSub";
            this.lblEstadoSub.Text = "Distribución total";
            // 
            // panelDonaEstado
            // 
            this.panelDonaEstado.Location = new System.Drawing.Point(20, 75);
            this.panelDonaEstado.Name = "panelDonaEstado";
            this.panelDonaEstado.Size = new System.Drawing.Size(170, 170);
            this.panelDonaEstado.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDonaEstado_Paint);
            // 
            // panelPunto1
            // 
            this.panelPunto1.BackColor = System.Drawing.Color.FromArgb(15, 39, 71);
            this.panelPunto1.Location = new System.Drawing.Point(210, 104);
            this.panelPunto1.Name = "panelPunto1";
            this.panelPunto1.Size = new System.Drawing.Size(10, 10);
            // 
            // panelPunto2
            // 
            this.panelPunto2.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.panelPunto2.Location = new System.Drawing.Point(210, 134);
            this.panelPunto2.Name = "panelPunto2";
            this.panelPunto2.Size = new System.Drawing.Size(10, 10);
            // 
            // panelPunto3
            // 
            this.panelPunto3.BackColor = System.Drawing.Color.FromArgb(147, 197, 253);
            this.panelPunto3.Location = new System.Drawing.Point(210, 164);
            this.panelPunto3.Name = "panelPunto3";
            this.panelPunto3.Size = new System.Drawing.Size(10, 10);
            // 
            // lblLeyenda1
            // 
            this.lblLeyenda1.AutoSize = true;
            this.lblLeyenda1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLeyenda1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyenda1.Location = new System.Drawing.Point(228, 100);
            this.lblLeyenda1.Name = "lblLeyenda1";
            this.lblLeyenda1.Text = "Pendientes";
            // 
            // lblLeyenda2
            // 
            this.lblLeyenda2.AutoSize = true;
            this.lblLeyenda2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLeyenda2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyenda2.Location = new System.Drawing.Point(228, 130);
            this.lblLeyenda2.Name = "lblLeyenda2";
            this.lblLeyenda2.Text = "En progreso";
            // 
            // lblLeyenda3
            // 
            this.lblLeyenda3.AutoSize = true;
            this.lblLeyenda3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblLeyenda3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyenda3.Location = new System.Drawing.Point(228, 160);
            this.lblLeyenda3.Name = "lblLeyenda3";
            this.lblLeyenda3.Text = "Finalizadas";
            // 
            // lblLeyendaValor1
            // 
            this.lblLeyendaValor1.AutoSize = true;
            this.lblLeyendaValor1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLeyendaValor1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyendaValor1.Location = new System.Drawing.Point(320, 100);
            this.lblLeyendaValor1.Name = "lblLeyendaValor1";
            this.lblLeyendaValor1.Text = "0";
            // 
            // lblLeyendaValor2
            // 
            this.lblLeyendaValor2.AutoSize = true;
            this.lblLeyendaValor2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLeyendaValor2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyendaValor2.Location = new System.Drawing.Point(320, 130);
            this.lblLeyendaValor2.Name = "lblLeyendaValor2";
            this.lblLeyendaValor2.Text = "0";
            // 
            // lblLeyendaValor3
            // 
            this.lblLeyendaValor3.AutoSize = true;
            this.lblLeyendaValor3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblLeyendaValor3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblLeyendaValor3.Location = new System.Drawing.Point(320, 160);
            this.lblLeyendaValor3.Name = "lblLeyendaValor3";
            this.lblLeyendaValor3.Text = "0";
            // 
            // panelProximas
            // 
            this.panelProximas.BackColor = System.Drawing.Color.White;
            this.panelProximas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelProximas.Controls.Add(this.lblProxTitulo);
            this.panelProximas.Controls.Add(this.lblProxSub);
            this.panelProximas.Controls.Add(this.panelProx1);
            this.panelProximas.Controls.Add(this.panelProx2);
            this.panelProximas.Controls.Add(this.panelProx3);
            this.panelProximas.Location = new System.Drawing.Point(30, 575);
            this.panelProximas.Name = "panelProximas";
            this.panelProximas.Size = new System.Drawing.Size(930, 160);
            // 
            // lblProxTitulo
            // 
            this.lblProxTitulo.AutoSize = true;
            this.lblProxTitulo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblProxTitulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProxTitulo.Location = new System.Drawing.Point(15, 14);
            this.lblProxTitulo.Name = "lblProxTitulo";
            this.lblProxTitulo.Text = "Próximas a finalizar";
            // 
            // lblProxSub
            // 
            this.lblProxSub.AutoSize = true;
            this.lblProxSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblProxSub.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProxSub.Location = new System.Drawing.Point(15, 38);
            this.lblProxSub.Name = "lblProxSub";
            this.lblProxSub.Text = "Tareas con fecha límite en los próximos días";
            // 
            // panelProx1
            // 
            this.panelProx1.BackColor = System.Drawing.Color.White;
            this.panelProx1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelProx1.Controls.Add(this.lblProx1Titulo);
            this.panelProx1.Controls.Add(this.lblProx1Proyecto);
            this.panelProx1.Controls.Add(this.lblProx1Fecha);
            this.panelProx1.Controls.Add(this.lblProx1Iniciales);
            this.panelProx1.Location = new System.Drawing.Point(15, 65);
            this.panelProx1.Name = "panelProx1";
            this.panelProx1.Size = new System.Drawing.Size(285, 80);
            // 
            // lblProx1Titulo
            // 
            this.lblProx1Titulo.AutoSize = true;
            this.lblProx1Titulo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblProx1Titulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProx1Titulo.Location = new System.Drawing.Point(12, 10);
            this.lblProx1Titulo.Name = "lblProx1Titulo";
            this.lblProx1Titulo.Text = "Tarea";
            // 
            // lblProx1Proyecto
            // 
            this.lblProx1Proyecto.AutoSize = true;
            this.lblProx1Proyecto.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblProx1Proyecto.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx1Proyecto.Location = new System.Drawing.Point(12, 32);
            this.lblProx1Proyecto.Name = "lblProx1Proyecto";
            this.lblProx1Proyecto.Text = "Proyecto";
            // 
            // lblProx1Fecha
            // 
            this.lblProx1Fecha.AutoSize = true;
            this.lblProx1Fecha.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblProx1Fecha.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx1Fecha.Location = new System.Drawing.Point(12, 52);
            this.lblProx1Fecha.Name = "lblProx1Fecha";
            this.lblProx1Fecha.Text = "Fecha";
            // 
            // lblProx1Iniciales
            // 
            this.lblProx1Iniciales.BackColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.lblProx1Iniciales.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProx1Iniciales.ForeColor = System.Drawing.Color.FromArgb(15, 39, 71);
            this.lblProx1Iniciales.Location = new System.Drawing.Point(240, 22);
            this.lblProx1Iniciales.Name = "lblProx1Iniciales";
            this.lblProx1Iniciales.Size = new System.Drawing.Size(32, 32);
            this.lblProx1Iniciales.Text = "";
            this.lblProx1Iniciales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelProx2
            // 
            this.panelProx2.BackColor = System.Drawing.Color.White;
            this.panelProx2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelProx2.Controls.Add(this.lblProx2Titulo);
            this.panelProx2.Controls.Add(this.lblProx2Proyecto);
            this.panelProx2.Controls.Add(this.lblProx2Fecha);
            this.panelProx2.Controls.Add(this.lblProx2Iniciales);
            this.panelProx2.Location = new System.Drawing.Point(315, 65);
            this.panelProx2.Name = "panelProx2";
            this.panelProx2.Size = new System.Drawing.Size(285, 80);
            // 
            // lblProx2Titulo
            // 
            this.lblProx2Titulo.AutoSize = true;
            this.lblProx2Titulo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblProx2Titulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProx2Titulo.Location = new System.Drawing.Point(12, 10);
            this.lblProx2Titulo.Name = "lblProx2Titulo";
            this.lblProx2Titulo.Text = "Tarea";
            // 
            // lblProx2Proyecto
            // 
            this.lblProx2Proyecto.AutoSize = true;
            this.lblProx2Proyecto.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblProx2Proyecto.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx2Proyecto.Location = new System.Drawing.Point(12, 32);
            this.lblProx2Proyecto.Name = "lblProx2Proyecto";
            this.lblProx2Proyecto.Text = "Proyecto";
            // 
            // lblProx2Fecha
            // 
            this.lblProx2Fecha.AutoSize = true;
            this.lblProx2Fecha.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblProx2Fecha.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx2Fecha.Location = new System.Drawing.Point(12, 52);
            this.lblProx2Fecha.Name = "lblProx2Fecha";
            this.lblProx2Fecha.Text = "Fecha";
            // 
            // lblProx2Iniciales
            // 
            this.lblProx2Iniciales.BackColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.lblProx2Iniciales.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProx2Iniciales.ForeColor = System.Drawing.Color.FromArgb(15, 39, 71);
            this.lblProx2Iniciales.Location = new System.Drawing.Point(240, 22);
            this.lblProx2Iniciales.Name = "lblProx2Iniciales";
            this.lblProx2Iniciales.Size = new System.Drawing.Size(32, 32);
            this.lblProx2Iniciales.Text = "";
            this.lblProx2Iniciales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panelProx3
            // 
            this.panelProx3.BackColor = System.Drawing.Color.White;
            this.panelProx3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelProx3.Controls.Add(this.lblProx3Titulo);
            this.panelProx3.Controls.Add(this.lblProx3Proyecto);
            this.panelProx3.Controls.Add(this.lblProx3Fecha);
            this.panelProx3.Controls.Add(this.lblProx3Iniciales);
            this.panelProx3.Location = new System.Drawing.Point(615, 65);
            this.panelProx3.Name = "panelProx3";
            this.panelProx3.Size = new System.Drawing.Size(285, 80);
            // 
            // lblProx3Titulo
            // 
            this.lblProx3Titulo.AutoSize = true;
            this.lblProx3Titulo.Font = new System.Drawing.Font("Segoe UI", 9.5F, System.Drawing.FontStyle.Bold);
            this.lblProx3Titulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblProx3Titulo.Location = new System.Drawing.Point(12, 10);
            this.lblProx3Titulo.Name = "lblProx3Titulo";
            this.lblProx3Titulo.Text = "Tarea";
            // 
            // lblProx3Proyecto
            // 
            this.lblProx3Proyecto.AutoSize = true;
            this.lblProx3Proyecto.Font = new System.Drawing.Font("Segoe UI", 8F);
            this.lblProx3Proyecto.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx3Proyecto.Location = new System.Drawing.Point(12, 32);
            this.lblProx3Proyecto.Name = "lblProx3Proyecto";
            this.lblProx3Proyecto.Text = "Proyecto";
            // 
            // lblProx3Fecha
            // 
            this.lblProx3Fecha.AutoSize = true;
            this.lblProx3Fecha.Font = new System.Drawing.Font("Segoe UI", 8.5F, System.Drawing.FontStyle.Bold);
            this.lblProx3Fecha.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblProx3Fecha.Location = new System.Drawing.Point(12, 52);
            this.lblProx3Fecha.Name = "lblProx3Fecha";
            this.lblProx3Fecha.Text = "Fecha";
            // 
            // lblProx3Iniciales
            // 
            this.lblProx3Iniciales.BackColor = System.Drawing.Color.FromArgb(226, 232, 240);
            this.lblProx3Iniciales.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProx3Iniciales.ForeColor = System.Drawing.Color.FromArgb(15, 39, 71);
            this.lblProx3Iniciales.Location = new System.Drawing.Point(240, 22);
            this.lblProx3Iniciales.Name = "lblProx3Iniciales";
            this.lblProx3Iniciales.Size = new System.Drawing.Size(32, 32);
            this.lblProx3Iniciales.Text = "";
            this.lblProx3Iniciales.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.ClientSize = new System.Drawing.Size(960, 708);
            this.Controls.Add(this.lblFecha);
            this.Controls.Add(this.lblSaludo);
            this.Controls.Add(this.lblSubtitulo);
            this.Controls.Add(this.panelHoras);
            this.Controls.Add(this.panelStat1);
            this.Controls.Add(this.panelStat2);
            this.Controls.Add(this.panelStat3);
            this.Controls.Add(this.panelStat4);
            this.Controls.Add(this.panelRecientes);
            this.Controls.Add(this.panelEstado);
            this.Controls.Add(this.panelProximas);
            this.Name = "Form2";
            this.Text = "Inicio";
            this.panelHoras.ResumeLayout(false);
            this.panelHoras.PerformLayout();
            this.panelStat1.ResumeLayout(false);
            this.panelStat1.PerformLayout();
            this.panelStat2.ResumeLayout(false);
            this.panelStat2.PerformLayout();
            this.panelStat3.ResumeLayout(false);
            this.panelStat3.PerformLayout();
            this.panelStat4.ResumeLayout(false);
            this.panelStat4.PerformLayout();
            this.panelRecientes.ResumeLayout(false);
            this.panelRecientes.PerformLayout();
            this.panelEstado.ResumeLayout(false);
            this.panelEstado.PerformLayout();
            this.panelProximas.ResumeLayout(false);
            this.panelProximas.PerformLayout();
            this.panelProx1.ResumeLayout(false);
            this.panelProx1.PerformLayout();
            this.panelProx2.ResumeLayout(false);
            this.panelProx2.PerformLayout();
            this.panelProx3.ResumeLayout(false);
            this.panelProx3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
