namespace ProyectoDeskstop
{
    partial class Form5
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblRendimiento;
        private System.Windows.Forms.Label lblTituloResumen;
        private System.Windows.Forms.Label lblSubResumen;
        private System.Windows.Forms.Panel panelStat1;
        private System.Windows.Forms.Label lblStatTitulo1;
        private System.Windows.Forms.Label lblStatValor1;
        private System.Windows.Forms.Panel panelStat2;
        private System.Windows.Forms.Label lblStatTitulo2;
        private System.Windows.Forms.Label lblStatValor2;
        private System.Windows.Forms.Panel panelStat3;
        private System.Windows.Forms.Label lblStatTitulo3;
        private System.Windows.Forms.Label lblStatValor3;
        private System.Windows.Forms.Panel panelStat4;
        private System.Windows.Forms.Label lblStatTitulo4;
        private System.Windows.Forms.Label lblStatValor4;
        private System.Windows.Forms.Panel panelEstadoResumen;
        private System.Windows.Forms.Label lblEstadoResTitulo;
        private System.Windows.Forms.Label lblEstadoResSub;
        private System.Windows.Forms.Panel panelDonaResumen;
        private System.Windows.Forms.Panel panelEstadoPunto1;
        private System.Windows.Forms.Label lblEstadoNombre1;
        private System.Windows.Forms.Label lblEstadoValor1;
        private System.Windows.Forms.Panel panelEstadoPunto2;
        private System.Windows.Forms.Label lblEstadoNombre2;
        private System.Windows.Forms.Label lblEstadoValor2;
        private System.Windows.Forms.Panel panelEstadoPunto3;
        private System.Windows.Forms.Label lblEstadoNombre3;
        private System.Windows.Forms.Label lblEstadoValor3;
        private System.Windows.Forms.Panel panelEstadoPunto4;
        private System.Windows.Forms.Label lblEstadoNombre4;
        private System.Windows.Forms.Label lblEstadoValor4;
        private System.Windows.Forms.Panel panelHorasProy;
        private System.Windows.Forms.Label lblHorasProyTitulo;
        private System.Windows.Forms.Label lblHorasProySub;
        private System.Windows.Forms.Label lblHorasNombre1;
        private System.Windows.Forms.Label lblHorasValor1;
        private System.Windows.Forms.ProgressBar pbHoras1;
        private System.Windows.Forms.Label lblHorasNombre2;
        private System.Windows.Forms.Label lblHorasValor2;
        private System.Windows.Forms.ProgressBar pbHoras2;
        private System.Windows.Forms.Label lblHorasNombre3;
        private System.Windows.Forms.Label lblHorasValor3;
        private System.Windows.Forms.ProgressBar pbHoras3;
        private System.Windows.Forms.Label lblHorasNombre4;
        private System.Windows.Forms.Label lblHorasValor4;
        private System.Windows.Forms.ProgressBar pbHoras4;
        private System.Windows.Forms.Panel panelResumenHoras;
        private System.Windows.Forms.Label lblHorasEstTitulo;
        private System.Windows.Forms.Label lblHorasEstValor;
        private System.Windows.Forms.Label lblHorasRegTitulo;
        private System.Windows.Forms.Label lblHorasRegValor;
        private System.Windows.Forms.Label lblUsoTitulo;
        private System.Windows.Forms.Label lblUsoValor;
        private System.Windows.Forms.ProgressBar pbUso;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        private void InitializeComponent()
        {
            this.lblRendimiento = new System.Windows.Forms.Label();
            this.lblTituloResumen = new System.Windows.Forms.Label();
            this.lblSubResumen = new System.Windows.Forms.Label();
            this.panelStat1 = new System.Windows.Forms.Panel();
            this.lblStatTitulo1 = new System.Windows.Forms.Label();
            this.lblStatValor1 = new System.Windows.Forms.Label();
            this.panelStat2 = new System.Windows.Forms.Panel();
            this.lblStatTitulo2 = new System.Windows.Forms.Label();
            this.lblStatValor2 = new System.Windows.Forms.Label();
            this.panelStat3 = new System.Windows.Forms.Panel();
            this.lblStatTitulo3 = new System.Windows.Forms.Label();
            this.lblStatValor3 = new System.Windows.Forms.Label();
            this.panelStat4 = new System.Windows.Forms.Panel();
            this.lblStatTitulo4 = new System.Windows.Forms.Label();
            this.lblStatValor4 = new System.Windows.Forms.Label();
            this.panelEstadoResumen = new System.Windows.Forms.Panel();
            this.lblEstadoResTitulo = new System.Windows.Forms.Label();
            this.lblEstadoResSub = new System.Windows.Forms.Label();
            this.panelDonaResumen = new System.Windows.Forms.Panel();
            this.panelEstadoPunto1 = new System.Windows.Forms.Panel();
            this.lblEstadoNombre1 = new System.Windows.Forms.Label();
            this.lblEstadoValor1 = new System.Windows.Forms.Label();
            this.panelEstadoPunto2 = new System.Windows.Forms.Panel();
            this.lblEstadoNombre2 = new System.Windows.Forms.Label();
            this.lblEstadoValor2 = new System.Windows.Forms.Label();
            this.panelEstadoPunto3 = new System.Windows.Forms.Panel();
            this.lblEstadoNombre3 = new System.Windows.Forms.Label();
            this.lblEstadoValor3 = new System.Windows.Forms.Label();
            this.panelEstadoPunto4 = new System.Windows.Forms.Panel();
            this.lblEstadoNombre4 = new System.Windows.Forms.Label();
            this.lblEstadoValor4 = new System.Windows.Forms.Label();
            this.panelHorasProy = new System.Windows.Forms.Panel();
            this.lblHorasProyTitulo = new System.Windows.Forms.Label();
            this.lblHorasProySub = new System.Windows.Forms.Label();
            this.lblHorasNombre1 = new System.Windows.Forms.Label();
            this.lblHorasValor1 = new System.Windows.Forms.Label();
            this.pbHoras1 = new System.Windows.Forms.ProgressBar();
            this.lblHorasNombre2 = new System.Windows.Forms.Label();
            this.lblHorasValor2 = new System.Windows.Forms.Label();
            this.pbHoras2 = new System.Windows.Forms.ProgressBar();
            this.lblHorasNombre3 = new System.Windows.Forms.Label();
            this.lblHorasValor3 = new System.Windows.Forms.Label();
            this.pbHoras3 = new System.Windows.Forms.ProgressBar();
            this.lblHorasNombre4 = new System.Windows.Forms.Label();
            this.lblHorasValor4 = new System.Windows.Forms.Label();
            this.pbHoras4 = new System.Windows.Forms.ProgressBar();
            this.panelResumenHoras = new System.Windows.Forms.Panel();
            this.lblHorasEstTitulo = new System.Windows.Forms.Label();
            this.lblHorasEstValor = new System.Windows.Forms.Label();
            this.lblHorasRegTitulo = new System.Windows.Forms.Label();
            this.lblHorasRegValor = new System.Windows.Forms.Label();
            this.lblUsoTitulo = new System.Windows.Forms.Label();
            this.lblUsoValor = new System.Windows.Forms.Label();
            this.pbUso = new System.Windows.Forms.ProgressBar();
            this.panelStat1.SuspendLayout();
            this.panelStat2.SuspendLayout();
            this.panelStat3.SuspendLayout();
            this.panelStat4.SuspendLayout();
            this.panelEstadoResumen.SuspendLayout();
            this.panelHorasProy.SuspendLayout();
            this.panelResumenHoras.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblRendimiento
            // 
            this.lblRendimiento.AutoSize = true;
            this.lblRendimiento.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblRendimiento.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblRendimiento.Location = new System.Drawing.Point(30, 20);
            this.lblRendimiento.Name = "lblRendimiento";
            this.lblRendimiento.Text = "RENDIMIENTO DEL EQUIPO";
            // 
            // lblTituloResumen
            // 
            this.lblTituloResumen.AutoSize = true;
            this.lblTituloResumen.Font = new System.Drawing.Font("Segoe UI", 22F);
            this.lblTituloResumen.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblTituloResumen.Location = new System.Drawing.Point(30, 40);
            this.lblTituloResumen.Name = "lblTituloResumen";
            this.lblTituloResumen.Text = "Resumen y estadísticas";
            // 
            // lblSubResumen
            // 
            this.lblSubResumen.AutoSize = true;
            this.lblSubResumen.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSubResumen.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblSubResumen.Location = new System.Drawing.Point(30, 85);
            this.lblSubResumen.Name = "lblSubResumen";
            this.lblSubResumen.Text = "Analiza el avance de los proyectos y el tiempo dedicado.";
            // 
            // panelStat1
            // 
            this.panelStat1.BackColor = System.Drawing.Color.White;
            this.panelStat1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat1.Controls.Add(this.lblStatTitulo1);
            this.panelStat1.Controls.Add(this.lblStatValor1);
            this.panelStat1.Location = new System.Drawing.Point(30, 125);
            this.panelStat1.Name = "panelStat1";
            this.panelStat1.Size = new System.Drawing.Size(225, 85);
            // 
            // lblStatTitulo1
            // 
            this.lblStatTitulo1.AutoSize = true;
            this.lblStatTitulo1.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStatTitulo1.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStatTitulo1.Location = new System.Drawing.Point(14, 14);
            this.lblStatTitulo1.Name = "lblStatTitulo1";
            this.lblStatTitulo1.Text = "Total de tareas";
            // 
            // lblStatValor1
            // 
            this.lblStatValor1.AutoSize = true;
            this.lblStatValor1.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStatValor1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStatValor1.Location = new System.Drawing.Point(14, 36);
            this.lblStatValor1.Name = "lblStatValor1";
            this.lblStatValor1.Text = "0";
            // 
            // panelStat2
            // 
            this.panelStat2.BackColor = System.Drawing.Color.White;
            this.panelStat2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat2.Controls.Add(this.lblStatTitulo2);
            this.panelStat2.Controls.Add(this.lblStatValor2);
            this.panelStat2.Location = new System.Drawing.Point(265, 125);
            this.panelStat2.Name = "panelStat2";
            this.panelStat2.Size = new System.Drawing.Size(225, 85);
            // 
            // lblStatTitulo2
            // 
            this.lblStatTitulo2.AutoSize = true;
            this.lblStatTitulo2.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStatTitulo2.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStatTitulo2.Location = new System.Drawing.Point(14, 14);
            this.lblStatTitulo2.Name = "lblStatTitulo2";
            this.lblStatTitulo2.Text = "Tareas finalizadas";
            // 
            // lblStatValor2
            // 
            this.lblStatValor2.AutoSize = true;
            this.lblStatValor2.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStatValor2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStatValor2.Location = new System.Drawing.Point(14, 36);
            this.lblStatValor2.Name = "lblStatValor2";
            this.lblStatValor2.Text = "0";
            // 
            // panelStat3
            // 
            this.panelStat3.BackColor = System.Drawing.Color.White;
            this.panelStat3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat3.Controls.Add(this.lblStatTitulo3);
            this.panelStat3.Controls.Add(this.lblStatValor3);
            this.panelStat3.Location = new System.Drawing.Point(500, 125);
            this.panelStat3.Name = "panelStat3";
            this.panelStat3.Size = new System.Drawing.Size(225, 85);
            // 
            // lblStatTitulo3
            // 
            this.lblStatTitulo3.AutoSize = true;
            this.lblStatTitulo3.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStatTitulo3.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStatTitulo3.Location = new System.Drawing.Point(14, 14);
            this.lblStatTitulo3.Name = "lblStatTitulo3";
            this.lblStatTitulo3.Text = "En progreso";
            // 
            // lblStatValor3
            // 
            this.lblStatValor3.AutoSize = true;
            this.lblStatValor3.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStatValor3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblStatValor3.Location = new System.Drawing.Point(14, 36);
            this.lblStatValor3.Name = "lblStatValor3";
            this.lblStatValor3.Text = "0";
            // 
            // panelStat4
            // 
            this.panelStat4.BackColor = System.Drawing.Color.FromArgb(239, 246, 255);
            this.panelStat4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelStat4.Controls.Add(this.lblStatTitulo4);
            this.panelStat4.Controls.Add(this.lblStatValor4);
            this.panelStat4.Location = new System.Drawing.Point(735, 125);
            this.panelStat4.Name = "panelStat4";
            this.panelStat4.Size = new System.Drawing.Size(225, 85);
            // 
            // lblStatTitulo4
            // 
            this.lblStatTitulo4.AutoSize = true;
            this.lblStatTitulo4.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblStatTitulo4.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblStatTitulo4.Location = new System.Drawing.Point(14, 14);
            this.lblStatTitulo4.Name = "lblStatTitulo4";
            this.lblStatTitulo4.Text = "Tasa de finalización";
            // 
            // lblStatValor4
            // 
            this.lblStatValor4.AutoSize = true;
            this.lblStatValor4.Font = new System.Drawing.Font("Segoe UI", 20F, System.Drawing.FontStyle.Bold);
            this.lblStatValor4.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblStatValor4.Location = new System.Drawing.Point(14, 36);
            this.lblStatValor4.Name = "lblStatValor4";
            this.lblStatValor4.Text = "0%";
            // 
            // panelEstadoResumen
            // 
            this.panelEstadoResumen.BackColor = System.Drawing.Color.White;
            this.panelEstadoResumen.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelEstadoResumen.Controls.Add(this.lblEstadoResTitulo);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoResSub);
            this.panelEstadoResumen.Controls.Add(this.panelDonaResumen);
            this.panelEstadoResumen.Controls.Add(this.panelEstadoPunto1);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoNombre1);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoValor1);
            this.panelEstadoResumen.Controls.Add(this.panelEstadoPunto2);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoNombre2);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoValor2);
            this.panelEstadoResumen.Controls.Add(this.panelEstadoPunto3);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoNombre3);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoValor3);
            this.panelEstadoResumen.Controls.Add(this.panelEstadoPunto4);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoNombre4);
            this.panelEstadoResumen.Controls.Add(this.lblEstadoValor4);
            this.panelEstadoResumen.Location = new System.Drawing.Point(30, 235);
            this.panelEstadoResumen.Name = "panelEstadoResumen";
            this.panelEstadoResumen.Size = new System.Drawing.Size(430, 300);
            // 
            // lblEstadoResTitulo
            // 
            this.lblEstadoResTitulo.AutoSize = true;
            this.lblEstadoResTitulo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblEstadoResTitulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoResTitulo.Location = new System.Drawing.Point(15, 14);
            this.lblEstadoResTitulo.Name = "lblEstadoResTitulo";
            this.lblEstadoResTitulo.Text = "Estado de las tareas";
            // 
            // lblEstadoResSub
            // 
            this.lblEstadoResSub.AutoSize = true;
            this.lblEstadoResSub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblEstadoResSub.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblEstadoResSub.Location = new System.Drawing.Point(15, 38);
            this.lblEstadoResSub.Name = "lblEstadoResSub";
            this.lblEstadoResSub.Text = "Distribución por estado";
            // 
            // panelDonaResumen
            // 
            this.panelDonaResumen.Location = new System.Drawing.Point(20, 75);
            this.panelDonaResumen.Name = "panelDonaResumen";
            this.panelDonaResumen.Size = new System.Drawing.Size(170, 170);
            this.panelDonaResumen.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDonaResumen_Paint);
            // 
            // panelEstadoPunto1
            // 
            this.panelEstadoPunto1.BackColor = System.Drawing.Color.FromArgb(15, 39, 71);
            this.panelEstadoPunto1.Location = new System.Drawing.Point(210, 99);
            this.panelEstadoPunto1.Name = "panelEstadoPunto1";
            this.panelEstadoPunto1.Size = new System.Drawing.Size(10, 10);
            // 
            // lblEstadoNombre1
            // 
            this.lblEstadoNombre1.AutoSize = true;
            this.lblEstadoNombre1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblEstadoNombre1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoNombre1.Location = new System.Drawing.Point(228, 95);
            this.lblEstadoNombre1.Name = "lblEstadoNombre1";
            this.lblEstadoNombre1.Text = "Pendientes";
            // 
            // lblEstadoValor1
            // 
            this.lblEstadoValor1.AutoSize = true;
            this.lblEstadoValor1.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblEstadoValor1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoValor1.Location = new System.Drawing.Point(340, 95);
            this.lblEstadoValor1.Name = "lblEstadoValor1";
            this.lblEstadoValor1.Text = "0";
            // 
            // panelEstadoPunto2
            // 
            this.panelEstadoPunto2.BackColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.panelEstadoPunto2.Location = new System.Drawing.Point(210, 144);
            this.panelEstadoPunto2.Name = "panelEstadoPunto2";
            this.panelEstadoPunto2.Size = new System.Drawing.Size(10, 10);
            // 
            // lblEstadoNombre2
            // 
            this.lblEstadoNombre2.AutoSize = true;
            this.lblEstadoNombre2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblEstadoNombre2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoNombre2.Location = new System.Drawing.Point(228, 140);
            this.lblEstadoNombre2.Name = "lblEstadoNombre2";
            this.lblEstadoNombre2.Text = "En progreso";
            // 
            // lblEstadoValor2
            // 
            this.lblEstadoValor2.AutoSize = true;
            this.lblEstadoValor2.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblEstadoValor2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoValor2.Location = new System.Drawing.Point(340, 140);
            this.lblEstadoValor2.Name = "lblEstadoValor2";
            this.lblEstadoValor2.Text = "0";
            // 
            // panelEstadoPunto3
            // 
            this.panelEstadoPunto3.BackColor = System.Drawing.Color.FromArgb(220, 38, 38);
            this.panelEstadoPunto3.Location = new System.Drawing.Point(210, 189);
            this.panelEstadoPunto3.Name = "panelEstadoPunto3";
            this.panelEstadoPunto3.Size = new System.Drawing.Size(10, 10);
            // 
            // lblEstadoNombre3
            // 
            this.lblEstadoNombre3.AutoSize = true;
            this.lblEstadoNombre3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblEstadoNombre3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoNombre3.Location = new System.Drawing.Point(228, 185);
            this.lblEstadoNombre3.Name = "lblEstadoNombre3";
            this.lblEstadoNombre3.Text = "Bloqueadas";
            // 
            // lblEstadoValor3
            // 
            this.lblEstadoValor3.AutoSize = true;
            this.lblEstadoValor3.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblEstadoValor3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoValor3.Location = new System.Drawing.Point(340, 185);
            this.lblEstadoValor3.Name = "lblEstadoValor3";
            this.lblEstadoValor3.Text = "0";
            // 
            // panelEstadoPunto4
            // 
            this.panelEstadoPunto4.BackColor = System.Drawing.Color.FromArgb(147, 197, 253);
            this.panelEstadoPunto4.Location = new System.Drawing.Point(210, 234);
            this.panelEstadoPunto4.Name = "panelEstadoPunto4";
            this.panelEstadoPunto4.Size = new System.Drawing.Size(10, 10);
            // 
            // lblEstadoNombre4
            // 
            this.lblEstadoNombre4.AutoSize = true;
            this.lblEstadoNombre4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblEstadoNombre4.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoNombre4.Location = new System.Drawing.Point(228, 230);
            this.lblEstadoNombre4.Name = "lblEstadoNombre4";
            this.lblEstadoNombre4.Text = "Finalizadas";
            // 
            // lblEstadoValor4
            // 
            this.lblEstadoValor4.AutoSize = true;
            this.lblEstadoValor4.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.lblEstadoValor4.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblEstadoValor4.Location = new System.Drawing.Point(340, 230);
            this.lblEstadoValor4.Name = "lblEstadoValor4";
            this.lblEstadoValor4.Text = "0";
            // 
            // panelHorasProy
            // 
            this.panelHorasProy.BackColor = System.Drawing.Color.White;
            this.panelHorasProy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelHorasProy.Controls.Add(this.lblHorasProyTitulo);
            this.panelHorasProy.Controls.Add(this.lblHorasProySub);
            this.panelHorasProy.Controls.Add(this.lblHorasNombre1);
            this.panelHorasProy.Controls.Add(this.lblHorasValor1);
            this.panelHorasProy.Controls.Add(this.pbHoras1);
            this.panelHorasProy.Controls.Add(this.lblHorasNombre2);
            this.panelHorasProy.Controls.Add(this.lblHorasValor2);
            this.panelHorasProy.Controls.Add(this.pbHoras2);
            this.panelHorasProy.Controls.Add(this.lblHorasNombre3);
            this.panelHorasProy.Controls.Add(this.lblHorasValor3);
            this.panelHorasProy.Controls.Add(this.pbHoras3);
            this.panelHorasProy.Controls.Add(this.lblHorasNombre4);
            this.panelHorasProy.Controls.Add(this.lblHorasValor4);
            this.panelHorasProy.Controls.Add(this.pbHoras4);
            this.panelHorasProy.Location = new System.Drawing.Point(480, 235);
            this.panelHorasProy.Name = "panelHorasProy";
            this.panelHorasProy.Size = new System.Drawing.Size(480, 300);
            // 
            // lblHorasProyTitulo
            // 
            this.lblHorasProyTitulo.AutoSize = true;
            this.lblHorasProyTitulo.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblHorasProyTitulo.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasProyTitulo.Location = new System.Drawing.Point(15, 14);
            this.lblHorasProyTitulo.Name = "lblHorasProyTitulo";
            this.lblHorasProyTitulo.Text = "Horas por proyecto";
            // 
            // lblHorasProySub
            // 
            this.lblHorasProySub.AutoSize = true;
            this.lblHorasProySub.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasProySub.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasProySub.Location = new System.Drawing.Point(15, 38);
            this.lblHorasProySub.Name = "lblHorasProySub";
            this.lblHorasProySub.Text = "Reales frente a estimadas";
            // 
            // lblHorasNombre1
            // 
            this.lblHorasNombre1.AutoSize = true;
            this.lblHorasNombre1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHorasNombre1.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasNombre1.Location = new System.Drawing.Point(15, 75);
            this.lblHorasNombre1.Name = "lblHorasNombre1";
            this.lblHorasNombre1.Text = "Proyecto 1";
            // 
            // lblHorasValor1
            // 
            this.lblHorasValor1.AutoSize = true;
            this.lblHorasValor1.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasValor1.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasValor1.Location = new System.Drawing.Point(300, 75);
            this.lblHorasValor1.Name = "lblHorasValor1";
            this.lblHorasValor1.Text = "0 h / 0 h";
            // 
            // pbHoras1
            // 
            this.pbHoras1.Location = new System.Drawing.Point(15, 97);
            this.pbHoras1.Name = "pbHoras1";
            this.pbHoras1.Size = new System.Drawing.Size(450, 10);
            // 
            // lblHorasNombre2
            // 
            this.lblHorasNombre2.AutoSize = true;
            this.lblHorasNombre2.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHorasNombre2.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasNombre2.Location = new System.Drawing.Point(15, 130);
            this.lblHorasNombre2.Name = "lblHorasNombre2";
            this.lblHorasNombre2.Text = "Proyecto 2";
            // 
            // lblHorasValor2
            // 
            this.lblHorasValor2.AutoSize = true;
            this.lblHorasValor2.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasValor2.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasValor2.Location = new System.Drawing.Point(300, 130);
            this.lblHorasValor2.Name = "lblHorasValor2";
            this.lblHorasValor2.Text = "0 h / 0 h";
            // 
            // pbHoras2
            // 
            this.pbHoras2.Location = new System.Drawing.Point(15, 152);
            this.pbHoras2.Name = "pbHoras2";
            this.pbHoras2.Size = new System.Drawing.Size(450, 10);
            // 
            // lblHorasNombre3
            // 
            this.lblHorasNombre3.AutoSize = true;
            this.lblHorasNombre3.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHorasNombre3.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasNombre3.Location = new System.Drawing.Point(15, 185);
            this.lblHorasNombre3.Name = "lblHorasNombre3";
            this.lblHorasNombre3.Text = "Proyecto 3";
            // 
            // lblHorasValor3
            // 
            this.lblHorasValor3.AutoSize = true;
            this.lblHorasValor3.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasValor3.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasValor3.Location = new System.Drawing.Point(300, 185);
            this.lblHorasValor3.Name = "lblHorasValor3";
            this.lblHorasValor3.Text = "0 h / 0 h";
            // 
            // pbHoras3
            // 
            this.pbHoras3.Location = new System.Drawing.Point(15, 207);
            this.pbHoras3.Name = "pbHoras3";
            this.pbHoras3.Size = new System.Drawing.Size(450, 10);
            // 
            // lblHorasNombre4
            // 
            this.lblHorasNombre4.AutoSize = true;
            this.lblHorasNombre4.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblHorasNombre4.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasNombre4.Location = new System.Drawing.Point(15, 240);
            this.lblHorasNombre4.Name = "lblHorasNombre4";
            this.lblHorasNombre4.Text = "Proyecto 4";
            // 
            // lblHorasValor4
            // 
            this.lblHorasValor4.AutoSize = true;
            this.lblHorasValor4.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasValor4.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasValor4.Location = new System.Drawing.Point(300, 240);
            this.lblHorasValor4.Name = "lblHorasValor4";
            this.lblHorasValor4.Text = "0 h / 0 h";
            // 
            // pbHoras4
            // 
            this.pbHoras4.Location = new System.Drawing.Point(15, 262);
            this.pbHoras4.Name = "pbHoras4";
            this.pbHoras4.Size = new System.Drawing.Size(450, 10);
            // 
            // panelResumenHoras
            // 
            this.panelResumenHoras.BackColor = System.Drawing.Color.White;
            this.panelResumenHoras.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panelResumenHoras.Controls.Add(this.lblHorasEstTitulo);
            this.panelResumenHoras.Controls.Add(this.lblHorasEstValor);
            this.panelResumenHoras.Controls.Add(this.lblHorasRegTitulo);
            this.panelResumenHoras.Controls.Add(this.lblHorasRegValor);
            this.panelResumenHoras.Controls.Add(this.lblUsoTitulo);
            this.panelResumenHoras.Controls.Add(this.lblUsoValor);
            this.panelResumenHoras.Controls.Add(this.pbUso);
            this.panelResumenHoras.Location = new System.Drawing.Point(30, 555);
            this.panelResumenHoras.Name = "panelResumenHoras";
            this.panelResumenHoras.Size = new System.Drawing.Size(930, 80);
            // 
            // lblHorasEstTitulo
            // 
            this.lblHorasEstTitulo.AutoSize = true;
            this.lblHorasEstTitulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasEstTitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasEstTitulo.Location = new System.Drawing.Point(20, 14);
            this.lblHorasEstTitulo.Name = "lblHorasEstTitulo";
            this.lblHorasEstTitulo.Text = "Horas estimadas";
            // 
            // lblHorasEstValor
            // 
            this.lblHorasEstValor.AutoSize = true;
            this.lblHorasEstValor.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblHorasEstValor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasEstValor.Location = new System.Drawing.Point(20, 32);
            this.lblHorasEstValor.Name = "lblHorasEstValor";
            this.lblHorasEstValor.Text = "624 h";
            // 
            // lblHorasRegTitulo
            // 
            this.lblHorasRegTitulo.AutoSize = true;
            this.lblHorasRegTitulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblHorasRegTitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblHorasRegTitulo.Location = new System.Drawing.Point(260, 14);
            this.lblHorasRegTitulo.Name = "lblHorasRegTitulo";
            this.lblHorasRegTitulo.Text = "Horas registradas";
            // 
            // lblHorasRegValor
            // 
            this.lblHorasRegValor.AutoSize = true;
            this.lblHorasRegValor.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblHorasRegValor.ForeColor = System.Drawing.Color.FromArgb(17, 24, 39);
            this.lblHorasRegValor.Location = new System.Drawing.Point(260, 32);
            this.lblHorasRegValor.Name = "lblHorasRegValor";
            this.lblHorasRegValor.Text = "486,5 h";
            // 
            // lblUsoTitulo
            // 
            this.lblUsoTitulo.AutoSize = true;
            this.lblUsoTitulo.Font = new System.Drawing.Font("Segoe UI", 8.5F);
            this.lblUsoTitulo.ForeColor = System.Drawing.Color.FromArgb(100, 116, 139);
            this.lblUsoTitulo.Location = new System.Drawing.Point(560, 14);
            this.lblUsoTitulo.Name = "lblUsoTitulo";
            this.lblUsoTitulo.Text = "Uso de horas";
            // 
            // lblUsoValor
            // 
            this.lblUsoValor.AutoSize = true;
            this.lblUsoValor.Font = new System.Drawing.Font("Segoe UI", 13F, System.Drawing.FontStyle.Bold);
            this.lblUsoValor.ForeColor = System.Drawing.Color.FromArgb(37, 99, 235);
            this.lblUsoValor.Location = new System.Drawing.Point(840, 10);
            this.lblUsoValor.Name = "lblUsoValor";
            this.lblUsoValor.Text = "0%";
            // 
            // pbUso
            // 
            this.pbUso.Location = new System.Drawing.Point(560, 52);
            this.pbUso.Name = "pbUso";
            this.pbUso.Size = new System.Drawing.Size(260, 10);
            // 
            // Form5
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.FromArgb(245, 247, 250);
            this.ClientSize = new System.Drawing.Size(960, 708);
            this.Controls.Add(this.lblRendimiento);
            this.Controls.Add(this.lblTituloResumen);
            this.Controls.Add(this.lblSubResumen);
            this.Controls.Add(this.panelStat1);
            this.Controls.Add(this.panelStat2);
            this.Controls.Add(this.panelStat3);
            this.Controls.Add(this.panelStat4);
            this.Controls.Add(this.panelEstadoResumen);
            this.Controls.Add(this.panelHorasProy);
            this.Controls.Add(this.panelResumenHoras);
            this.Name = "Form5";
            this.Text = "Resumen";
            this.panelStat1.ResumeLayout(false);
            this.panelStat1.PerformLayout();
            this.panelStat2.ResumeLayout(false);
            this.panelStat2.PerformLayout();
            this.panelStat3.ResumeLayout(false);
            this.panelStat3.PerformLayout();
            this.panelStat4.ResumeLayout(false);
            this.panelStat4.PerformLayout();
            this.panelEstadoResumen.ResumeLayout(false);
            this.panelEstadoResumen.PerformLayout();
            this.panelHorasProy.ResumeLayout(false);
            this.panelHorasProy.PerformLayout();
            this.panelResumenHoras.ResumeLayout(false);
            this.panelResumenHoras.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        #endregion
    }
}
